let mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/checkout', {
  useNewUrlParser: true,
  useUnifiedTopology: true
 });

let schema = new mongoose.Schema({
  name: String,
  email: String,
  password: String
});

let CheckoutData = mongoose.model('checkoutData', schema);

module.exports = CheckoutData;