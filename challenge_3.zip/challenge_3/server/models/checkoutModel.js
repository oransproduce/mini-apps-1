let db = require('../../database');

const getData = (cb) => {
  //db.find()
};

const postData = (data, cb) => {
  console.log(data);
  db.create({
    name: data.name,
    email: data.email,
    password: data.password
  }, (err, results) => {
    if (err) {
      cb(err);
    } else {
      cb(null, results);
    }
  })
};

const putData = (data, cb) => {

};

module.exports = {
  getData,
  postData,
  putData
};