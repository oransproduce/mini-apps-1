class Form1 extends React.Component {
  constructor(props) {
    super(props)
    let state = this.returnNewBlankState();
    console.log('ran ' + state);
    // this.state = {
    //   name: '',
    //   email: '',
    //   password: ''
    // };
    this.state = state;
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onChange(event) {
    console.log('triggering');
    this.setState({
      [event.target.name]: event.target.value
    })
  }

  onSubmit(event) {
    event.preventDefault();
    console.log('submission');
    let saveState = Object.fromEntries(Object.entries(this.state));
    let state = this.returnNewBlankState();
    this.setState({}, () => {
      console.log('fire', this.state);
    });
    this.props.next(saveState);

  }

  returnNewBlankState() {
    let newState = {};
    for (let field of this.props.fieldNames) {
      newState[field] = '';
    }
    return newState;
  }
  render() {
  //   return (
  //    <form onSubmit={this.onSubmit}>
  //      <div>
  //       <label>
  //         Name:
  //         <input onChange={this.onChange} name='name' type='text' value={this.state.name}></input>
  //       </label>
  //      </div>
  //      <div>
  //       <label>
  //         Email:
  //         <input onChange={this.onChange} name='email' type='text' value={this.state.email}></input>
  //       </label>
  //      </div>
  //      <div>
  //       <label>
  //         Password:
  //         <input onChange={this.onChange} name='password' type='text' value={this.state.password}></input>
  //       </label>
  //      </div>
  //      <div>
  //       <input type='submit' value='Next'></input>
  //      </div>
  //    </form>
  //  );
    return (
      <form onSubmit = {this.onSubmit}>
        {this.props.fieldNames.map((field, key, val) => <FormInput field={field} fieldValue={this.state.field} change={this.onChange} key={key} val={'test'}/>)}
        <div>
          <input type='submit' value='Next'></input>
        </div>
      </form>
    )
  }
 }

let FormInput = (props) => (
  <div>
    <label>
      {props.field}
      <input onChange={props.change} name={props.field} type='text' value={props.fieldValue}></input>
    </label>
  </div>
 )

class Form2 extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      address1: '',
      [this.props.fieldName]: '',
      city: '',
      state: '',
      zip: '',
      phone: ''
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onChange(event) {
    console.log('triggering');
    this.setState({
      [event.target.name]: event.target.value
    })
  }

  onSubmit(event) {
    event.preventDefault();
    console.log('submission');
    this.props.next(this.state);
    this.setState({
      address1: '',
      [this.props.fieldName]: '',
      city: '',
      state: '',
      zip: '',
      phone: ''
    });
  }
  render() {
    return (
     <form onSubmit={this.onSubmit}>
       <div>
        <label>
          Address Line 1:
          <input onChange={this.onChange} name='address1' type='text' value={this.state.name}></input>
        </label>
       </div>
       <div>
        <label>
          {this.props.fieldName}
          <input onChange={this.onChange} name={this.props.fieldName} type='text' value={this.state.email}></input>
        </label>
       </div>
       <div>
        <label>
          City:
          <input onChange={this.onChange} name='city' type='text' value={this.state.password}></input>
        </label>
       </div>
       <div>
        <label>
          State:
          <input onChange={this.onChange} name='state' type='text' value={this.state.password}></input>
        </label>
       </div>
       <div>
        <label>
          Zip:
          <input onChange={this.onChange} name='zip' type='text' value={this.state.password}></input>
        </label>
       </div>
       <div>
        <label>
          Phone Number:
          <input onChange={this.onChange} name='phone' type='text' value={this.state.password}></input>
        </label>
       </div>
       <div>
        <input type='submit' value='Next'></input>
       </div>
     </form>
   );
  }
 }

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      checkout: false,
      formCounter: 0,
      currentID: ''
    }
  }

  next(data) {
    this.setState(state => ({
      formCounter: state.formCounter + 1
    }), () => {
      console.log('water', this.state);
    });
    console.log(data);
    // axios.post('http://localhost:3000/checkout', data).then(results => {
    //   this.setState({
    //     currentID: results.data._id
    //   });
    // }).catch(err => {
    //   console.log(err);
    // });

  }

  checkout() {
    this.setState({
      checkout: true
    })
  }

  render() {
    let firstForm = <Form1 next={this.next.bind(this)} fieldNames={['name', 'email', 'password']}/>;
    let secondForm = <Form1 next={this.next.bind(this)} fieldNames={['address1', 'address2', 'city', 'state', 'zip', 'phone']}/>
    if (this.state.checkout && this.state.formCounter === 0) {
      return (
        <div>
          {firstForm}
        </div>
      )
    } else if (this.state.checkout && this.state.formCounter === 1) {
      return (
        <div>
          {secondForm}
        </div>
      )
    } else {
      return (
        <button onClick={this.checkout.bind(this)}>Checkout</button>
      )
    }

  }
}




ReactDOM.render(<App />, document.getElementById('app'));